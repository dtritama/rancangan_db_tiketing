--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.transportasi DROP CONSTRAINT transportasi_pkey;
ALTER TABLE ONLY public.rute DROP CONSTRAINT rute_pkey;
ALTER TABLE ONLY public.petugas DROP CONSTRAINT petugas_pkey;
ALTER TABLE ONLY public.penumpang DROP CONSTRAINT penumpang_pkey;
ALTER TABLE ONLY public.pemesanan DROP CONSTRAINT pemesanan_pkey;
DROP TABLE public.type_transportasi;
DROP TABLE public.transportasi;
DROP TABLE public.rute;
DROP TABLE public.petugas;
DROP TABLE public.penumpang;
DROP TABLE public.pemesanan;
DROP TABLE public.levels;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: levels; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE levels (
    id_level integer,
    nama_level character varying(100)
);


ALTER TABLE levels OWNER TO postgres;

--
-- Name: pemesanan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pemesanan (
    id_pemesanan character varying(20) NOT NULL,
    kode_pemesanan character varying(20),
    tanggal_pemesanan date,
    tempat_pemesanan character varying(25),
    id_pelanggan character varying(15),
    kode_kursi character varying(15),
    id_rute character varying(15),
    tujuan text,
    tanggal_berangkat date,
    jam_cekin time without time zone,
    jam_berangkat time without time zone,
    total_bayar integer,
    id_petugas character varying(15)
);


ALTER TABLE pemesanan OWNER TO postgres;

--
-- Name: penumpang; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penumpang (
    id_penumpang character varying(15) NOT NULL,
    username character varying(30),
    password character varying(30),
    nama_penumpang character varying(100),
    alamat_penumpang text,
    tanggal_lahir date,
    jenis_kelamin character varying(11),
    telefone character varying(12)
);


ALTER TABLE penumpang OWNER TO postgres;

--
-- Name: petugas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE petugas (
    id_petugas character varying(15) NOT NULL,
    username character varying(50),
    password character varying(30),
    nama_petugas character varying(100),
    id_level integer
);


ALTER TABLE petugas OWNER TO postgres;

--
-- Name: rute; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE rute (
    id_rute character varying(15) NOT NULL,
    tujuan text,
    rute_awal text,
    rute_akhir text,
    harga integer,
    id_transportasi character varying(20)
);


ALTER TABLE rute OWNER TO postgres;

--
-- Name: transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE transportasi (
    id_transportasi character varying(20) NOT NULL,
    kode integer,
    jumlah_kursi integer,
    keterangan text,
    id_type_transportasi integer
);


ALTER TABLE transportasi OWNER TO postgres;

--
-- Name: type_transportasi; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE type_transportasi (
    id_type_transportasi integer,
    nama_type character varying(20),
    keterangan text
);


ALTER TABLE type_transportasi OWNER TO postgres;

--
-- Data for Name: levels; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY levels (id_level, nama_level) FROM stdin;
\.
COPY levels (id_level, nama_level) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: pemesanan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM stdin;
\.
COPY pemesanan (id_pemesanan, kode_pemesanan, tanggal_pemesanan, tempat_pemesanan, id_pelanggan, kode_kursi, id_rute, tujuan, tanggal_berangkat, jam_cekin, jam_berangkat, total_bayar, id_petugas) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: penumpang; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telefone) FROM stdin;
\.
COPY penumpang (id_penumpang, username, password, nama_penumpang, alamat_penumpang, tanggal_lahir, jenis_kelamin, telefone) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: petugas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM stdin;
\.
COPY petugas (id_petugas, username, password, nama_petugas, id_level) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: rute; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM stdin;
\.
COPY rute (id_rute, tujuan, rute_awal, rute_akhir, harga, id_transportasi) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM stdin;
\.
COPY transportasi (id_transportasi, kode, jumlah_kursi, keterangan, id_type_transportasi) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: type_transportasi; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY type_transportasi (id_type_transportasi, nama_type, keterangan) FROM stdin;
\.
COPY type_transportasi (id_type_transportasi, nama_type, keterangan) FROM '$$PATH$$/2834.dat';

--
-- Name: pemesanan pemesanan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pemesanan
    ADD CONSTRAINT pemesanan_pkey PRIMARY KEY (id_pemesanan);


--
-- Name: penumpang penumpang_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penumpang
    ADD CONSTRAINT penumpang_pkey PRIMARY KEY (id_penumpang);


--
-- Name: petugas petugas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY petugas
    ADD CONSTRAINT petugas_pkey PRIMARY KEY (id_petugas);


--
-- Name: rute rute_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY rute
    ADD CONSTRAINT rute_pkey PRIMARY KEY (id_rute);


--
-- Name: transportasi transportasi_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY transportasi
    ADD CONSTRAINT transportasi_pkey PRIMARY KEY (id_transportasi);


--
-- PostgreSQL database dump complete
--

